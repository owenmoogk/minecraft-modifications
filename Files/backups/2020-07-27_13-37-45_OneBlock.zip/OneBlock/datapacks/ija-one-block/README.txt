﻿
███ ████ ████ █   █ ███ █   █ ████  ██  ███  ████ ████ █████
 █     █ █  █ ██ ██  █  ██  █ █    █  █ █  █ █  █ █      █
 █     █ ████ █ █ █  █  █ █ █ ████ █    ███  ████ ████   █
 █  █  █ █  █ █   █  █  █  ██ █    █  █ █  █ █  █ █      █
███  ██  █  █ █   █ ███ █   █ ████  ██  █  █ █  █ █      █

This work was created and is copyrighted by IJAMinecraft.

Visit IJAMinecraft here:
Website: ijaminecraft.com
YouTube: youtube.com/user/IJAMinecraft


 ██   ██  ███  █ █ ███  ███  ███ █  █ █████
█  █ █  █ █  █ █ █ █  █  █  █    █  █   █
█    █  █ ███   █  ███   █  █ ██ ████   █ 
█  █ █  █ █     █  █  █  █  █  █ █  █   █
 ██   ██  █     █  █  █ ███  ██  █  █   █

For information on how and where you're allowed to use and showcase this work, look at the text file 'LICENSE.txt'.